USE [Master]
GO
if db_id('CompanyCustomer') is NULL
BEGIN
CREATE DATABASE [CompanyCustomer] ON  PRIMARY 
( NAME = N'CompanyCustomer', FILENAME = N'c:\CompanyCustomer.mdf' , SIZE = 2GB , MAXSIZE = 8GB, FILEGROWTH = 1GB )
LOG ON 
( NAME = N'CompanyCustomer_log', FILENAME = N'c:\CompanyCustomer_log.ldf' , SIZE = 1GB , MAXSIZE = 2GB , FILEGROWTH = 10%)

END
GO

USE [CompanyCustomer]
GO

IF OBJECT_ID('dbo.COMPANY')IS NULL
BEGIN
	CREATE TABLE dbo.COMPANY
	(
		id	int identity(1,1) not null,
		CompanyName nvarchar(100) not null,
		Address		nvarchar(200) null

	)
	
	ALTER TABLE dbo.COMPANY WITH NOCHECK ADD
		CONSTRAINT PK_COMPANY PRIMARY KEY  CLUSTERED
	       (id)  ON [PRIMARY] 

END
GO

IF OBJECT_ID('dbo.CUSTOMER')IS NULL
BEGIN
	CREATE TABLE dbo.CUSTOMER
	(
		id	int identity(1,1) not null,
		CustomerName nvarchar(100) not null,
		Address		nvarchar(200) null,
		CompanyId	int not null
	)
	
	ALTER TABLE dbo.CUSTOMER WITH NOCHECK ADD
		CONSTRAINT PK_CUSTOMER PRIMARY KEY  CLUSTERED
	       (id)  ON [PRIMARY] 

END
GO

If OBJECT_ID('FK_COMPANY') Is Null
BEGIN
ALTER TABLE [dbo].CUSTOMER WITH NOCHECK 
    ADD CONSTRAINT [FK_COMPANY] FOREIGN KEY
    ([CompanyId]) REFERENCES [dbo].[COMPANY] ([id])
     NOT FOR REPLICATION
END
GO