﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CompanyCustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtCompanyName = New System.Windows.Forms.TextBox()
        Me.lblCompanyName = New System.Windows.Forms.Label()
        Me.lblCompanyAddress = New System.Windows.Forms.Label()
        Me.txtCompanyAddress = New System.Windows.Forms.TextBox()
        Me.dgvCompany = New System.Windows.Forms.DataGridView()
        Me.dgvCustomer = New System.Windows.Forms.DataGridView()
        Me.lblCustomerAddress = New System.Windows.Forms.Label()
        Me.txtCustomerAddress = New System.Windows.Forms.TextBox()
        Me.lblCustomerName = New System.Windows.Forms.Label()
        Me.txtCustomerName = New System.Windows.Forms.TextBox()
        Me.lblCustomerId = New System.Windows.Forms.Label()
        Me.lblCustomerIDValue = New System.Windows.Forms.Label()
        Me.lblCompanyIdValue = New System.Windows.Forms.Label()
        Me.lblCompnayId = New System.Windows.Forms.Label()
        Me.btnSaveCompany = New System.Windows.Forms.Button()
        Me.btnSaveCustomer = New System.Windows.Forms.Button()
        Me.btnDeleteCompany = New System.Windows.Forms.Button()
        Me.btnClearCompany = New System.Windows.Forms.Button()
        Me.btnClearCustomer = New System.Windows.Forms.Button()
        Me.btnDeleteCustomer = New System.Windows.Forms.Button()
        CType(Me.dgvCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtCompanyName
        '
        Me.txtCompanyName.Location = New System.Drawing.Point(133, 49)
        Me.txtCompanyName.Name = "txtCompanyName"
        Me.txtCompanyName.Size = New System.Drawing.Size(100, 20)
        Me.txtCompanyName.TabIndex = 0
        '
        'lblCompanyName
        '
        Me.lblCompanyName.AutoSize = True
        Me.lblCompanyName.Location = New System.Drawing.Point(29, 52)
        Me.lblCompanyName.Name = "lblCompanyName"
        Me.lblCompanyName.Size = New System.Drawing.Size(82, 13)
        Me.lblCompanyName.TabIndex = 1
        Me.lblCompanyName.Text = "Company Name"
        '
        'lblCompanyAddress
        '
        Me.lblCompanyAddress.AutoSize = True
        Me.lblCompanyAddress.Location = New System.Drawing.Point(66, 78)
        Me.lblCompanyAddress.Name = "lblCompanyAddress"
        Me.lblCompanyAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblCompanyAddress.TabIndex = 3
        Me.lblCompanyAddress.Text = "Address"
        '
        'txtCompanyAddress
        '
        Me.txtCompanyAddress.Location = New System.Drawing.Point(133, 75)
        Me.txtCompanyAddress.Name = "txtCompanyAddress"
        Me.txtCompanyAddress.Size = New System.Drawing.Size(100, 20)
        Me.txtCompanyAddress.TabIndex = 2
        '
        'dgvCompany
        '
        Me.dgvCompany.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCompany.Location = New System.Drawing.Point(261, 48)
        Me.dgvCompany.Name = "dgvCompany"
        Me.dgvCompany.Size = New System.Drawing.Size(564, 150)
        Me.dgvCompany.TabIndex = 4
        '
        'dgvCustomer
        '
        Me.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCustomer.Location = New System.Drawing.Point(261, 227)
        Me.dgvCustomer.Name = "dgvCustomer"
        Me.dgvCustomer.Size = New System.Drawing.Size(564, 150)
        Me.dgvCustomer.TabIndex = 9
        '
        'lblCustomerAddress
        '
        Me.lblCustomerAddress.AutoSize = True
        Me.lblCustomerAddress.Location = New System.Drawing.Point(66, 257)
        Me.lblCustomerAddress.Name = "lblCustomerAddress"
        Me.lblCustomerAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblCustomerAddress.TabIndex = 8
        Me.lblCustomerAddress.Text = "Address"
        '
        'txtCustomerAddress
        '
        Me.txtCustomerAddress.Location = New System.Drawing.Point(133, 254)
        Me.txtCustomerAddress.Name = "txtCustomerAddress"
        Me.txtCustomerAddress.Size = New System.Drawing.Size(100, 20)
        Me.txtCustomerAddress.TabIndex = 7
        '
        'lblCustomerName
        '
        Me.lblCustomerName.AutoSize = True
        Me.lblCustomerName.Location = New System.Drawing.Point(29, 231)
        Me.lblCustomerName.Name = "lblCustomerName"
        Me.lblCustomerName.Size = New System.Drawing.Size(82, 13)
        Me.lblCustomerName.TabIndex = 6
        Me.lblCustomerName.Text = "Customer Name"
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Location = New System.Drawing.Point(133, 228)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.Size = New System.Drawing.Size(100, 20)
        Me.txtCustomerName.TabIndex = 5
        '
        'lblCustomerId
        '
        Me.lblCustomerId.AutoSize = True
        Me.lblCustomerId.Location = New System.Drawing.Point(29, 200)
        Me.lblCustomerId.Name = "lblCustomerId"
        Me.lblCustomerId.Size = New System.Drawing.Size(82, 13)
        Me.lblCustomerId.TabIndex = 10
        Me.lblCustomerId.Text = "Customer Name"
        Me.lblCustomerId.Visible = False
        '
        'lblCustomerIDValue
        '
        Me.lblCustomerIDValue.AutoSize = True
        Me.lblCustomerIDValue.Location = New System.Drawing.Point(130, 200)
        Me.lblCustomerIDValue.Name = "lblCustomerIDValue"
        Me.lblCustomerIDValue.Size = New System.Drawing.Size(13, 13)
        Me.lblCustomerIDValue.TabIndex = 11
        Me.lblCustomerIDValue.Text = "0"
        Me.lblCustomerIDValue.Visible = False
        '
        'lblCompanyIdValue
        '
        Me.lblCompanyIdValue.AutoSize = True
        Me.lblCompanyIdValue.Location = New System.Drawing.Point(130, 27)
        Me.lblCompanyIdValue.Name = "lblCompanyIdValue"
        Me.lblCompanyIdValue.Size = New System.Drawing.Size(13, 13)
        Me.lblCompanyIdValue.TabIndex = 13
        Me.lblCompanyIdValue.Text = "0"
        Me.lblCompanyIdValue.Visible = False
        '
        'lblCompnayId
        '
        Me.lblCompnayId.AutoSize = True
        Me.lblCompnayId.Location = New System.Drawing.Point(29, 27)
        Me.lblCompnayId.Name = "lblCompnayId"
        Me.lblCompnayId.Size = New System.Drawing.Size(82, 13)
        Me.lblCompnayId.TabIndex = 12
        Me.lblCompnayId.Text = "Company Name"
        Me.lblCompnayId.Visible = False
        '
        'btnSaveCompany
        '
        Me.btnSaveCompany.Location = New System.Drawing.Point(12, 144)
        Me.btnSaveCompany.Name = "btnSaveCompany"
        Me.btnSaveCompany.Size = New System.Drawing.Size(75, 23)
        Me.btnSaveCompany.TabIndex = 14
        Me.btnSaveCompany.Text = "Save"
        Me.btnSaveCompany.UseVisualStyleBackColor = True
        '
        'btnSaveCustomer
        '
        Me.btnSaveCustomer.Location = New System.Drawing.Point(12, 329)
        Me.btnSaveCustomer.Name = "btnSaveCustomer"
        Me.btnSaveCustomer.Size = New System.Drawing.Size(75, 23)
        Me.btnSaveCustomer.TabIndex = 15
        Me.btnSaveCustomer.Text = "Save"
        Me.btnSaveCustomer.UseVisualStyleBackColor = True
        '
        'btnDeleteCompany
        '
        Me.btnDeleteCompany.Location = New System.Drawing.Point(93, 144)
        Me.btnDeleteCompany.Name = "btnDeleteCompany"
        Me.btnDeleteCompany.Size = New System.Drawing.Size(75, 23)
        Me.btnDeleteCompany.TabIndex = 16
        Me.btnDeleteCompany.Text = "Delete"
        Me.btnDeleteCompany.UseVisualStyleBackColor = True
        '
        'btnClearCompany
        '
        Me.btnClearCompany.Location = New System.Drawing.Point(180, 144)
        Me.btnClearCompany.Name = "btnClearCompany"
        Me.btnClearCompany.Size = New System.Drawing.Size(75, 23)
        Me.btnClearCompany.TabIndex = 17
        Me.btnClearCompany.Text = "Clear"
        Me.btnClearCompany.UseVisualStyleBackColor = True
        '
        'btnClearCustomer
        '
        Me.btnClearCustomer.Location = New System.Drawing.Point(180, 329)
        Me.btnClearCustomer.Name = "btnClearCustomer"
        Me.btnClearCustomer.Size = New System.Drawing.Size(75, 23)
        Me.btnClearCustomer.TabIndex = 19
        Me.btnClearCustomer.Text = "Clear"
        Me.btnClearCustomer.UseVisualStyleBackColor = True
        '
        'btnDeleteCustomer
        '
        Me.btnDeleteCustomer.Location = New System.Drawing.Point(93, 329)
        Me.btnDeleteCustomer.Name = "btnDeleteCustomer"
        Me.btnDeleteCustomer.Size = New System.Drawing.Size(75, 23)
        Me.btnDeleteCustomer.TabIndex = 18
        Me.btnDeleteCustomer.Text = "Delete"
        Me.btnDeleteCustomer.UseVisualStyleBackColor = True
        '
        'CompanyCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(935, 405)
        Me.Controls.Add(Me.btnClearCustomer)
        Me.Controls.Add(Me.btnDeleteCustomer)
        Me.Controls.Add(Me.btnClearCompany)
        Me.Controls.Add(Me.btnDeleteCompany)
        Me.Controls.Add(Me.btnSaveCustomer)
        Me.Controls.Add(Me.btnSaveCompany)
        Me.Controls.Add(Me.lblCompanyIdValue)
        Me.Controls.Add(Me.lblCompnayId)
        Me.Controls.Add(Me.lblCustomerIDValue)
        Me.Controls.Add(Me.lblCustomerId)
        Me.Controls.Add(Me.dgvCustomer)
        Me.Controls.Add(Me.lblCustomerAddress)
        Me.Controls.Add(Me.txtCustomerAddress)
        Me.Controls.Add(Me.lblCustomerName)
        Me.Controls.Add(Me.txtCustomerName)
        Me.Controls.Add(Me.dgvCompany)
        Me.Controls.Add(Me.lblCompanyAddress)
        Me.Controls.Add(Me.txtCompanyAddress)
        Me.Controls.Add(Me.lblCompanyName)
        Me.Controls.Add(Me.txtCompanyName)
        Me.Name = "CompanyCustomer"
        Me.Text = "Company Customer Project"
        CType(Me.dgvCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtCompanyName As System.Windows.Forms.TextBox
    Friend WithEvents lblCompanyName As System.Windows.Forms.Label
    Friend WithEvents lblCompanyAddress As System.Windows.Forms.Label
    Friend WithEvents txtCompanyAddress As System.Windows.Forms.TextBox
    Friend WithEvents dgvCompany As System.Windows.Forms.DataGridView
    Friend WithEvents dgvCustomer As System.Windows.Forms.DataGridView
    Friend WithEvents lblCustomerAddress As System.Windows.Forms.Label
    Friend WithEvents txtCustomerAddress As System.Windows.Forms.TextBox
    Friend WithEvents lblCustomerName As System.Windows.Forms.Label
    Friend WithEvents txtCustomerName As System.Windows.Forms.TextBox
    Friend WithEvents lblCustomerId As System.Windows.Forms.Label
    Friend WithEvents lblCustomerIDValue As System.Windows.Forms.Label
    Friend WithEvents lblCompanyIdValue As System.Windows.Forms.Label
    Friend WithEvents lblCompnayId As System.Windows.Forms.Label
    Friend WithEvents btnSaveCompany As System.Windows.Forms.Button
    Friend WithEvents btnSaveCustomer As System.Windows.Forms.Button
    Friend WithEvents btnDeleteCompany As System.Windows.Forms.Button
    Friend WithEvents btnClearCompany As System.Windows.Forms.Button
    Friend WithEvents btnClearCustomer As System.Windows.Forms.Button
    Friend WithEvents btnDeleteCustomer As System.Windows.Forms.Button

End Class
