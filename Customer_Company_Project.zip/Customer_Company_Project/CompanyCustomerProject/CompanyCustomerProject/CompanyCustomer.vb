﻿Public Class CompanyCustomer

    Private Sub CompanyCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call LoadCompany()
    End Sub

    Private Sub LoadCompany()
        Using context As New CompanyCustomerEntities
            context.Configuration.LazyLoadingEnabled = False
            Dim CompanyList = (From x In context.COMPANies Select x.id, x.CompanyName, x.Address).ToList

            If CompanyList.Count > 0 Then
                dgvCompany.DataSource = CompanyList
                dgvCompany.Refresh()
            Else
                dgvCompany.DataSource = Nothing
            End If

        End Using
    End Sub

    Private Sub LoadCustomers(CompanyId As String)
        Using context As New CompanyCustomerEntities
            context.Configuration.LazyLoadingEnabled = False
            Dim CustomerList = (From x In context.CUSTOMERs Where x.CompanyId = CompanyId Select x.id, x.CustomerName, x.Address).ToList

            If CustomerList.Count > 0 Then
                dgvCustomer.DataSource = CustomerList
                dgvCustomer.Refresh()
            Else
                dgvCustomer.DataSource = Nothing
            End If

        End Using
    End Sub

    Private Sub btnSaveCompany_Click(sender As Object, e As EventArgs) Handles btnSaveCompany.Click
        Dim CompanyId As Integer = Convert.ToInt32(lblCompanyIdValue.Text.ToString)

        If txtCompanyName.Text <> "" Then
            Using context = New CompanyCustomerEntities
                If CompanyId = 0 Then
                    Dim comp As COMPANY = New COMPANY
                    comp.CompanyName = txtCompanyName.Text
                    comp.Address = txtCompanyAddress.Text
                    context.COMPANies.Add(comp)
                Else
                    Dim comp = context.COMPANies.FirstOrDefault(Function(co) co.id = CompanyId)
                    comp.CompanyName = txtCompanyName.Text
                    comp.Address = txtCompanyAddress.Text
                End If
                context.SaveChanges()
            End Using
            Call LoadCompany()
            Call CompanyClearValues()
            Call CustomerClearValues()
        End If
    End Sub

 
    Private Sub dgvCompany_SelectionChanged(sender As Object, e As EventArgs) Handles dgvCompany.SelectionChanged
        Dim row As DataGridViewRow = Nothing

        If dgvCompany.CurrentCell.Selected Then
            row = dgvCompany.CurrentRow
            Dim CompanyId = row.Cells("id").Value.ToString

            lblCompanyIdValue.Text = row.Cells("id").Value.ToString
            txtCompanyName.Text = row.Cells("CompanyName").Value.ToString
            txtCompanyAddress.Text = row.Cells("Address").Value.ToString

            Call LoadCustomers(CompanyId)
            Call CustomerClearValues()
        End If

    End Sub

    Private Sub btnDeleteCompany_Click(sender As Object, e As EventArgs) Handles btnDeleteCompany.Click
        Dim row As DataGridViewRow = Nothing
        If dgvCompany.Rows.Count > 0 Then
            If dgvCompany.CurrentCell.Selected Then
                row = dgvCompany.CurrentRow
                Dim CompanyId As String = row.Cells("id").Value.ToString

                Using context = New CompanyCustomerEntities

                    Dim comp = context.COMPANies.FirstOrDefault(Function(co) co.id = CompanyId)
                    context.COMPANies.Remove(comp)
                    Dim cust = (From c In context.CUSTOMERs Where c.CompanyId = CompanyId Select c).ToList
                    If cust.Count > 0 Then
                        For Each c In cust
                            context.CUSTOMERs.Remove(c)
                        Next
                    End If
                    context.SaveChanges()
                End Using
                Call LoadCompany()
                If dgvCompany.Rows.Count > 0 Then
                    row = dgvCompany.CurrentRow
                    CompanyId = row.Cells("id").Value.ToString
                End If
                Call LoadCustomers(CompanyId)
                Call CompanyClearValues()
            End If
        End If
    End Sub

    Private Sub btnClearCompany_Click(sender As Object, e As EventArgs) Handles btnClearCompany.Click
        Call CompanyClearValues()
    End Sub

    Private Sub CompanyClearValues()
        lblCompanyIdValue.Text = "0"
        txtCompanyName.Text = ""
        txtCompanyAddress.Text = ""
    End Sub

    Private Sub CustomerClearValues()
        lblCustomerIDValue.Text = "0"
        txtCustomerName.Text = ""
        txtCustomerAddress.Text = ""
    End Sub

    Private Sub btnSaveCustomer_Click(sender As Object, e As EventArgs) Handles btnSaveCustomer.Click
        Dim CustomerId As Integer = Convert.ToInt32(lblCustomerIDValue.Text.ToString)
        If dgvCompany.Rows.Count > 0 Then
            If txtCustomerName.Text <> "" And dgvCompany.CurrentCell.Selected Then
                Dim CompanyId = dgvCompany.CurrentRow.Cells("id").Value.ToString
                Using context = New CompanyCustomerEntities
                    If CustomerId = 0 Then
                        Dim cust As CUSTOMER = New CUSTOMER
                        cust.CustomerName = txtCustomerName.Text
                        cust.Address = txtCompanyAddress.Text
                        cust.CompanyId = CompanyId
                        context.CUSTOMERs.Add(cust)
                    Else
                        Dim cust = context.CUSTOMERs.FirstOrDefault(Function(co) co.id = CustomerId)
                        cust.CustomerName = txtCustomerName.Text
                        cust.Address = txtCompanyAddress.Text
                    End If
                    context.SaveChanges()
                End Using
                Call LoadCustomers(CompanyId)
                Call CustomerClearValues()
            End If
        End If
    End Sub

    Private Sub btnDeleteCustomer_Click(sender As Object, e As EventArgs) Handles btnDeleteCustomer.Click
        Dim rowCust As DataGridViewRow = Nothing
        Dim rowComp As DataGridViewRow = Nothing

        If dgvCompany.Rows.Count > 0 Then
            If dgvCustomer.CurrentCell.Selected And dgvCompany.CurrentCell.Selected Then

                rowCust = dgvCustomer.CurrentRow
                rowComp = dgvCompany.CurrentRow
                Dim CustomerId As String = rowCust.Cells("id").Value.ToString
                Dim CompanyId As String = rowComp.Cells("id").Value.ToString

                Using context = New CompanyCustomerEntities

                    Dim cust = context.CUSTOMERs.FirstOrDefault(Function(co) co.id = CustomerId)

                    context.CUSTOMERs.Remove(cust)
                    context.SaveChanges()
                End Using

                Call LoadCustomers(CompanyId)
                Call CustomerClearValues()
            End If
        End If
    End Sub

    Private Sub btnClearCustomer_Click(sender As Object, e As EventArgs) Handles btnClearCustomer.Click
        Call CustomerClearValues()
    End Sub

    Private Sub dgvCustomer_SelectionChanged(sender As Object, e As EventArgs) Handles dgvCustomer.SelectionChanged
        Dim row As DataGridViewRow = Nothing

        If dgvCustomer.CurrentCell.Selected Then
            row = dgvCustomer.CurrentRow
            lblCustomerIDValue.Text = row.Cells("id").Value.ToString
            txtCustomerName.Text = row.Cells("CustomerName").Value.ToString
            txtCustomerAddress.Text = row.Cells("Address").Value.ToString

        End If
    End Sub
End Class
