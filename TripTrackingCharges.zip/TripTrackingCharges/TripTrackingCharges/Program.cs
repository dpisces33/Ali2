﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace TripTrackingCharges
{
    class Program
    {
        public static void Main(string[] args)
        {
            if (args == null || args.Length == 0)
            {
                Console.WriteLine("Please specify a filename as a parameter.");
                return;
            }

            string line;
            List<Participent> ListParticipent = new List<Participent>();
            StreamReader Inputfile = new StreamReader(args[0]);
            decimal AverageParticipentCharges;

            while(decimal.Parse(line = Inputfile.ReadLine()) != 0)
            {
                Participent p = new Participent();
                p.TotalParticipentCharges = new List<decimal>();
                p.NumOfParticipent  = Int32.Parse(line);

                for (int j = 1; j <= p.NumOfParticipent;j++ )
                {
                    p.NumOfCharges = Int32.Parse(Inputfile.ReadLine());
                    Decimal TotalParticipentCharges = 0;
                    for (int i = 1; i <= p.NumOfCharges; i++)
                    {
                        TotalParticipentCharges += Decimal.Parse(Inputfile.ReadLine());
                    }
                    p.TotalParticipentCharges.Add(TotalParticipentCharges);

                    p.ToTalGroupCharges += TotalParticipentCharges;
                }

                ListParticipent.Add(p);

            }

            
            using (System.IO.StreamWriter Outputfile =new System.IO.StreamWriter(args[0] + ".out"))
            {
                foreach (Participent p in ListParticipent)
                {
                    
                    AverageParticipentCharges = p.ToTalGroupCharges / p.NumOfParticipent;
                    foreach (decimal ParticipentCharges in p.TotalParticipentCharges)
                    {
                        Outputfile.WriteLine(string.Format("{0:$#,##0.00;($#,##0.00)}", Math.Round(AverageParticipentCharges - ParticipentCharges, 2)));
                    }

                    Outputfile.WriteLine();
                }
            }


        }
    }
}
